#ifndef VOIP_MODULES_AUDIO_PROCESSING_UTILITY_FFT4G_H_
#define VOIP_MODULES_AUDIO_PROCESSING_UTILITY_FFT4G_H_

void Voip_rdft(int, int, float *, int *, float *);
void Voip_cdft(int, int, float *, int *, float *);

#endif

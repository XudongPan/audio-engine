
/*
 * This file contains the function VoIPSpl_get_version().
 * The description header can be found in signal_processing_library.h
 *
 */

#include <string.h>
#include "audio_engine/common_audio/signal_processing/include/signal_processing_library.h"

int16_t VoipSpl_get_version(char* version, int16_t length_in_bytes)
{
    strncpy(version, "1.2.0", length_in_bytes);
    return 0;
}
